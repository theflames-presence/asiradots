killall pavucontrol
pavucontrol

