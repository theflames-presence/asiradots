Special thanks to [https://github.com/akx/Notifications
](https://github.com/akx/Notifications).

The sound is licensed under [CC0 1.0 Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/).
